DR AI ANDROID PROJECT — READ THIS FIRST

Aapke liye starter Android project tayyar hai. Is ZIP mein Android app ka source code aur GitHub par APK build karne ki automatic workflow hai.

IMPORTANT LIMITATIONS:
1. Yeh abhi starter version 1 hai, final full AI assistant nahi.
2. Mic button dabakar voice command chalti hai. “Hello DR AI” always-on wake word abhi included nahi hai.
3. Call command sirf phone ka dialer kholta hai; bina confirmation/number ke call nahi karta.
4. SMS command message composer kholta hai. Automatic message send nahi karta.
5. WhatsApp command WhatsApp app kholta hai; automatic message send nahi karta.
6. Basic commands phone ki speech recognition service par depend karti hain.
7. OpenAI chat/API abhi configured nahi. OpenAI API key ki zaroorat ho sakti hai aur API usage free guaranteed nahi hai.
8. Lock-screen always-on control aur background microphone is starter mein included nahi hai.

APK BUILD (Android phone se):
A. GitHub account banayein / sign in karein: https://github.com
B. New repository banayein, naam: DR-AI-Android
C. Is ZIP ko extract karke iske andar ki sab files repository mein upload karein. ZIP ko sirf ZIP file ke roop mein upload na karein; folders/files repository root mein hon.
D. Commit changes karein.
E. Repository ke Actions tab mein “Build DR AI APK” workflow kholen.
F. “Run workflow” dabayein. Build complete hone par workflow run kholen.
G. Artifacts mein “DR-AI-debug-APK” download karein. ZIP extract karke app-debug.apk par tap karein.
H. Android prompt aaye to “Install unknown apps” ki permission sirf GitHub/browser se APK install karne ke liye allow karein. Install ke baad permission band kar sakte hain.

BUILD ERROR AAYE TO:
Actions run ka error screenshot/text bhejein. Main uske hisaab se project update karunga.

PACKAGE: com.drinnovationagency.drai
APP NAME: DR AI
VERSION: 1.0
