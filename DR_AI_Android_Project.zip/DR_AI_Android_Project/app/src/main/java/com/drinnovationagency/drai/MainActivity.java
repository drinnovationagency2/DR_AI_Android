package com.drinnovationagency.drai;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 101;
    private TextView status, heard;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,20,38));
        getWindow().setNavigationBarColor(Color.rgb(7,20,38));
        buildScreen();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("hi", "IN"));
                ttsReady = true;
            }
        });
    }

    private void buildScreen() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(28, 42, 28, 24);
        page.setBackgroundColor(Color.rgb(7,20,38));

        TextView brand = new TextView(this);
        brand.setText("DR AI");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(36);
        brand.setGravity(Gravity.CENTER);
        brand.setTypeface(null, 1);
        page.addView(brand, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("YOUR PERSONAL VOICE ASSISTANT");
        subtitle.setTextColor(Color.rgb(0,200,255));
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 8, 0, 34);
        page.addView(subtitle, matchWrap());

        Button listen = new Button(this);
        listen.setText("🎤  TAP TO SPEAK");
        listen.setTextSize(18);
        listen.setAllCaps(false);
        page.addView(listen, fullWidth(64));
        listen.setOnClickListener(v -> startListening());

        status = new TextView(this);
        status.setText("Ready. Tap the microphone and speak.");
        status.setTextColor(Color.WHITE);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 28, 0, 12);
        page.addView(status, matchWrap());

        heard = new TextView(this);
        heard.setText("Try: “YouTube kholo”, “Papa ko call karo”, “WhatsApp kholo”.");
        heard.setTextColor(Color.LTGRAY);
        heard.setTextSize(14);
        heard.setGravity(Gravity.CENTER);
        heard.setPadding(8, 8, 8, 24);
        page.addView(heard, matchWrap());

        addActionButton(page, "📞  CALL", () -> dialNumber());
        addActionButton(page, "💬  WHATSAPP", () -> openWhatsApp());
        addActionButton(page, "▶  YOUTUBE", () -> openPackage("com.google.android.youtube"));
        addActionButton(page, "🌐  BROWSER", () -> openUrl("https://www.google.com"));

        TextView footer = new TextView(this);
        footer.setText("POWERED BY DR INNOVATION AGENCY");
        footer.setTextColor(Color.rgb(120,150,180));
        footer.setTextSize(10);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, 28, 0, 0);
        page.addView(footer, matchWrap());

        setContentView(page);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private LinearLayout.LayoutParams fullWidth(int h) {
        return new LinearLayout.LayoutParams(-1, h);
    }
    private void addActionButton(LinearLayout page, String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = fullWidth(52);
        p.topMargin = 8;
        page.addView(b, p);
        b.setOnClickListener(v -> action.run());
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "DR AI ko command dein");
            startActivityForResult(i, 102);
            status.setText("Listening…");
        } catch (ActivityNotFoundException e) {
            speak("Is phone mein speech recognition service available nahi hai.");
            status.setText("Speech recognition service not available.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 102 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String command = results.get(0);
                heard.setText("You said: " + command);
                handleCommand(command.toLowerCase(Locale.ROOT));
            }
        }
    }

    private void handleCommand(String c) {
        if (c.contains("youtube")) {
            speak("YouTube khol raha hoon"); openPackage("com.google.android.youtube");
        } else if (c.contains("whatsapp")) {
            speak("WhatsApp khol raha hoon"); openWhatsApp();
        } else if (c.contains("chrome") || c.contains("browser") || c.contains("internet")) {
            speak("Browser khol raha hoon"); openUrl("https://www.google.com");
        } else if (c.contains("call") || c.contains("कॉल") || c.contains("phone")) {
            speak("Call karne ke liye number dial karein");
            dialNumber();
        } else if (c.contains("message") || c.contains("मैसेज") || c.contains("sms")) {
            speak("Message screen khol raha hoon");
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"));
            safeStart(i);
        } else if (c.contains("time") || c.contains("समय")) {
            String t = new java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new java.util.Date());
            speak("Abhi samay hai " + t);
            status.setText("Time: " + t);
        } else {
            speak("Main abhi YouTube, WhatsApp, browser, call aur message commands samajh sakta hoon. Aur commands agle version mein add karenge.");
            status.setText("Command not recognised. Try a supported command.");
        }
    }

    private void dialNumber() {
        Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"));
        safeStart(i);
    }
    private void openWhatsApp() {
        openPackage("com.whatsapp");
    }
    private void openPackage(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) safeStart(i);
        else {
            Toast.makeText(this, "App installed nahi hai.", Toast.LENGTH_SHORT).show();
            if (pkg.equals("com.whatsapp")) openUrl("https://www.whatsapp.com/android");
            else if (pkg.contains("youtube")) openUrl("https://www.youtube.com");
        }
    }
    private void openUrl(String url) {
        safeStart(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }
    private void safeStart(Intent i) {
        try { startActivity(i); }
        catch (Exception e) { Toast.makeText(this, "Is action ke liye app available nahi hai.", Toast.LENGTH_LONG).show(); }
    }
    private void speak(String message) {
        status.setText(message);
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "dr-ai-utterance");
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_AUDIO && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else Toast.makeText(this, "Voice ke liye microphone permission zaroori hai.", Toast.LENGTH_LONG).show();
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
